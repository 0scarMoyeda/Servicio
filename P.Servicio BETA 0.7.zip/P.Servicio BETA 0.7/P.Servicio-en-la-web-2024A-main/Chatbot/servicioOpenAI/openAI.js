const { RecursiveCharacterTextSplitter } = require('langchain/text_splitter');
const { OpenAIEmbeddings, ChatOpenAI } = require('@langchain/openai');
const dotenv = require('dotenv');
//Retriever libraries
const { HNSWLib } = require('@langchain/community/vectorstores/hnswlib')
const { formatDocumentsAsString } = require('langchain/util/document');
const { RunnablePassthrough, RunnableSequence } = require('@langchain/core/runnables');
const { StringOutputParser } = require('@langchain/core/output_parsers');
const { ChatPromptTemplate } = require('@langchain/core/prompts');
const { HumanMessagePromptTemplate } = require('@langchain/core/prompts');
const { SystemMessagePromptTemplate } = require('@langchain/core/prompts');
const fs = require('fs');

//cargar las variables de entorno
dotenv.config();

//Función que retorna la respuesta a la pregunta del usuario
async function responderPregunta(pregunta, carrera){
  //Selección del modelo y cargado de embeddings
  const model = new ChatOpenAI({modelName: "gpt-4-0125-preview", temperature: 0});
  const vectorStore = await createEmbeddings(carrera);
  
  // Initialize a retriever wrapper around the vector store
  const vectorStoreRetriever = vectorStore.asRetriever({k:3});

  //const resultOne = await vectorStore.similaritySearch(pregunta,3);
  //console.log(resultOne);
  
  // Create a system & human prompt for the chat model
  const SYSTEM_TEMPLATE = `Utilice los siguientes elementos de contexto para responder la pregunta del usuario. Este contexto se obtuvo de una base de conocimientos de preguntas y respuestas y usted debe utilizar solo los hechos del contexto para responder.
  Tu respuesta debe basarse en el contexto. Si el contexto no contiene la respuesta, simplemente diga "No sé", no intente inventar una respuesta, use el contexto.
  No aborde el contexto directamente, utilícelo para responder la pregunta del usuario como si fuera su propio conocimiento.
  Solo haz caso a la primera pregunta, las demas son parte del contexto.
  ----------------
  {context}`;
  const messages = [
    SystemMessagePromptTemplate.fromTemplate(SYSTEM_TEMPLATE),
    HumanMessagePromptTemplate.fromTemplate("{question}"),
  ];
  const prompt = ChatPromptTemplate.fromMessages(messages);

  const chain = RunnableSequence.from([
    {
      context: vectorStoreRetriever.pipe(formatDocumentsAsString),
      question: new RunnablePassthrough(),
    },
    prompt,
    model,
    new StringOutputParser(),
  ]);

  //Se hace la pregunta del usuario
  const answer = await chain.invoke(
    pregunta
  );

  //console.log({ answer });
  return answer;

}

//Función para responder al usuario sobre su tutor
async function responderTutor(pregunta, carrera, tutor){
  //Selección del modelo y cargado de embeddings
  const model = new ChatOpenAI({temperature: 0});
  const vectorStore = await createEmbeddings(carrera);

  // Initialize a retriever wrapper around the vector store
  const vectorStoreRetriever = vectorStore.asRetriever({k:1});

  // Create a system & human prompt for the chat model
  const SYSTEM_TEMPLATE = `Utiliza los siguientes elementos de contexto para responder la pregunta del usuario. Este contexto se obtuvo de una base de conocimientos y usted debe utilizar solo los hechos del contexto para responder.
  Tu respuesta debe basarse en el contexto. Si el contexto no contiene la respuesta, simplemente diga "No sé", no intente inventar una respuesta, use el contexto.
  No aborde el contexto directamente, utilícelo para responder la pregunta del usuario como si fuera su propio conocimiento.
  ----------------
  {context}`+ ` tutor: ` + tutor;

  const messages = [
    SystemMessagePromptTemplate.fromTemplate(SYSTEM_TEMPLATE),
    HumanMessagePromptTemplate.fromTemplate("{question}"),
  ];
  const prompt = ChatPromptTemplate.fromMessages(messages);

  const chain = RunnableSequence.from([
    {
      context: vectorStoreRetriever.pipe(formatDocumentsAsString),
      question: new RunnablePassthrough(),
    },
    prompt,
    model,
    new StringOutputParser(),
  ]);

  //Se hace la pregunta del usuario
  const answer = await chain.invoke(
    pregunta
  );

  //console.log({ answer });
  return answer;
}

//Funcion para crear los embeddings en la carpeta stuff
async function createEmbeddings(carrera){
  try {
    //Se intentan cargar los embeddings de la carpeta stuff
    const vectorStore = await HNSWLib.load("./preguntas/"+carrera, new OpenAIEmbeddings({modelName: "text-embedding-3-large"}));
    return vectorStore;
  }
  // Crea los embeddings si estos no han sido creados
  catch(error) {
    try{
    console.log("Los embeddings estan siendo creados");
    const text = fs.readFileSync("./preguntas/Preguntas"+carrera+".txt", "utf8");
    const textSplitter = new RecursiveCharacterTextSplitter({chunkSize: 20, separators: '}', chunkOverlap: 5});
    const docs = await textSplitter.createDocuments([text]);
    console.log(docs);
    // Create a vector store from the documents.
    const vectorStore = await HNSWLib.fromDocuments(docs, new OpenAIEmbeddings({modelName: "text-embedding-3-large"}));

    await vectorStore.save("./preguntas/"+carrera);
    return vectorStore;
    }catch(err){
      const noDataMessage = await HNSWLib.fromTexts(["No data", "No tengo información de esa carrera", "No data"],
      [{ id: 2 }, { id: 1 }, { id: 3 }], new OpenAIEmbeddings());
      return noDataMessage;
    }
  }
}

//responderPregunta("Que es el articulo 34?");

module.exports = {
  responderPregunta,
  responderTutor
}