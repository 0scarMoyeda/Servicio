async function sendMessage(){    
    var messageInput = document.getElementById("chat-input");
    var message = messageInput.value.trim();
    if (message !== "") {
        var chatMessages = document.getElementById("chat-messages");
        var newMessageContainer = document.createElement("div"); // div utilizado para relacionar una pregunta y una respuesta
        var newMessageElement = document.createElement("div");
        newMessageElement.style.textAlign = "right";
        newMessageElement.className += "BordesMensajes";

        newMessageElement.className += " MensajeUsuario"; // clase utilizada para obtener el mensaje en el feedback
        newMessageContainer.className += "MessagesContainer"; // contenedor de una pregunta y respuesta
        newMessageContainer.appendChild(newMessageElement);


        newMessageElement.innerHTML = "<p>"+"<span> Tu: </span>" + "<span class='TextUserQuestion'>" +message+ "</span>"+"</p>"

        var entrada = document.getElementById("chat-input");
        chatMessages.appendChild(newMessageContainer);
        messageInput.value = ""; // Limpiar el campo de entrada después de enviar el mensaje.
        chatMessages.scrollTop = chatMessages.scrollHeight; // Desplazar hacia abajo para mostrar el último mensaje.
        entrada.disabled = true;

        try{
            fetch('/enviarMensaje', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ mensaje: message })
            })
            .then(response => response.json())
            .then(data => {
                console.log(data.respuesta)
                chatResponse = data.respuesta;
                var elementoMensajeBot = document.createElement("div");
                elementoMensajeBot.style.textAlign = "left";
                elementoMensajeBot.className += "BordesMensajesBot";

                elementoMensajeBot.innerHTML = "<p>"+"<span> Bot: </span>" + "<span class='TextBotResponse'>" +data.respuesta + 
                "</span><br><span class='botonesIconos material-symbols-outlined like'>thumb_up </span>                 "+
                "<span class='botonesIconos material-symbols-outlined dislike'>thumb_down</span>"+"</p>";

                // agregar mensaje del bot al container
                newMessageContainer.appendChild(elementoMensajeBot);
                chatMessages.scrollTop = chatMessages.scrollHeight;

                // Obtener los elementos de los iconos de like y dislike
                var likeIcon = elementoMensajeBot.querySelector('.like');
                var dislikeIcon = elementoMensajeBot.querySelector('.dislike');
                entrada.disabled = false;
                
                // Añadir eventos de clic a los iconos
                likeIcon.addEventListener('click', () => {
                    console.log('Se ha presionado el botón de like');
                });

                dislikeIcon.addEventListener('click', dislikeModal);

            })
            .catch(error => console.error('Error:', error));
        }
        catch (error){
            console.error("Error al obtener respuesta:", error);
            elementoMensajeBot.innerHTML = "<span> Bot: </span>" + "<span> Error en la conexion con los tutores </span>"
            newMessageContainer.appendChild(elementoMensajeBot);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }
}
// funcion accedida desde el html
async function sendFeedback() {
    // Obtener el texto del feedback en el modal
    let feedbackText = document.getElementById("input-feedback").value;
    // recortar el texto del feedback si sobrepasa los 450 caracteres
    if (feedbackText.length > 450) {
        feedbackText = feedbackText.slice(0, 450);
    }
    // si el feedback no contiene texto informar al usuario
    else if (feedbackText.length < 1) {
        document.getElementById("feedback-warning").style.display = "block";
        return;
    }
    document.getElementById("feedback-warning").style.display = "none";

    // Obtener la pregunta del usuario y la respuesta del chatbot desde los atributos de datos
    const question = document.getElementById("btn-send-feedback").getAttribute('data-question');
    const response = document.getElementById("btn-send-feedback").getAttribute('data-response');
    
    var modal = document.getElementById("modal-feedback");
    modal.style.display = "none";
    document.getElementById("input-feedback").value = "";

    try {
        fetch('/enviarFeedback', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ pregunta: question, respuesta: response, feedback: feedbackText})
        })
        .then(response => {
            if (response.ok) {
                response.text().then(data => {
                    feedbackConfirm();
                });
            } else {
                console.error('Error en la respuesta del servidor:', response.status);
            }
        })
        .catch(error => console.error('Error:', error));
    }
    catch (error){
        console.error("Error al enviar feedback:", error);
    }
}

// Modal de comentarios sobre el chatbot
async function dislikeModal() {
    // Obtener el contenedor del mensaje del usuario y del botón Dislike
    var dislikeButton = this; // 'this' se refiere al botón Dislike que ha sido presionado
    var messageContainer = dislikeButton.closest('.MessagesContainer');
    const btnSendFeedback = document.getElementById("btn-send-feedback");

    // Obtener el mensaje del usuario y la respuesta del chatbot dentro del contenedor
    var userMessage = messageContainer.querySelector('.MensajeUsuario .TextUserQuestion').innerText;
    var botResponse = messageContainer.querySelector('.BordesMensajesBot .TextBotResponse').innerText;
    btnSendFeedback.setAttribute('data-question', userMessage);
    btnSendFeedback.setAttribute('data-response', botResponse);
    
    // window.open("https://forms.gle/f7VNyd3DDCkNwznb9", "_blank");
    // Get the modal
    var modal = document.getElementById("modal-feedback");
    modal.style.display = "block";
    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close-feedback")[0];
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
        document.getElementById("input-feedback").value = "";
        document.getElementById("feedback-warning").style.display = "none";
    }
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
            document.getElementById("input-feedback").value = "";
            document.getElementById("feedback-warning").style.display = "none";
        }
    }
    // botonCerrarModal
    const botonCerrarModal = document.getElementById("botonCerrarModal");
    botonCerrarModal.onclick = function() {
        modal.style.display = "none";
        document.getElementById("input-feedback").value = "";
        document.getElementById("feedback-warning").style.display = "none";
    }

    // Obtener todos los botones con la clase 'default-response'
    const defaultResponseButtons = document.querySelectorAll('.default-response');

    // Iterar sobre cada botón y agregar un event listener
    defaultResponseButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Obtener el texto del atributo 'data-text' y asignarlo al campo de entrada
            const buttonText = button.getAttribute('data-text');
            document.getElementById("input-feedback").value = buttonText;
        });
    });
}

// Este es el pequeño modal que le dice al usuario que
// ya se enviaron sus comentarios
function feedbackConfirm() {
    let span = document.getElementsByClassName("close-feedback")[1];
    let modalConfirm = document.getElementById("feedback-confirm");
    modalConfirm.style.display = "block";
    span.onclick = function() {
        modalConfirm.style.display = "none";
    }
}