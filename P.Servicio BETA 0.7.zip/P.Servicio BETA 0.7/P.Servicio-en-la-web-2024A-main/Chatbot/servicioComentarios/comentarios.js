// NOTA: Este script se encarga de mandar el feedback del usuario
// respecto a una respuesta del bot hacia una base de datos

const mysql = require('mysql');

//Conexión con la base de datos tutores
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'tutores'
});

// Función para conectar a la base de datos
function connectToDatabase() {
    return new Promise((resolve, reject) => {
        connection.connect(err => {
            if (err) {
                reject(err);
            } else {
                console.log("Conexión establecida");
                resolve();
            }
        });
    });
}

// Funcion para ingresar datos a la tabla de feedback
function addFeedback(codigoAlumno, pregunta, respuesta, comentFeedback) {
    return new Promise((resolve, reject) => {
        const query = 'INSERT INTO feedback (codigo_alumno, pregunta, respuesta, feedback) VALUES (?, ?, ?, ?)';
        connection.query(query, [codigoAlumno, pregunta, respuesta, comentFeedback], (error, results) => {
            if (error) {
                reject(error);
            } else {
                resolve(results);
            }
        });
    });
}

// Funcion a exportar para subir los comentarios del usuario
async function submitFeedback(codigoAlumno, pregunta, respuesta, feedback) {
    try {
        //await connectToDatabase();
        await addFeedback(codigoAlumno, pregunta, respuesta, feedback);
        console.log("Feedback agregado correctamente");
    } catch (error) {
        console.error("Error al agregar feedback:", error);
    } /* finally {
        connection.end(); // Cerrar conexión después de usarla
    } */
}

module.exports = {
    submitFeedback
}