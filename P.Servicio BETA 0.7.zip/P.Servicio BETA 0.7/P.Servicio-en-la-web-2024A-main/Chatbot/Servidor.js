const http = require('http');
const fs = require('fs');
const path = require('path');
const {askQuestionBot} = require('./Controlador');
const {submitFeedback} = require('./servicioComentarios/comentarios');
const dotenv = require('dotenv');
dotenv.config();

const server = http.createServer((req, res) => {
    if (req.method === 'POST' && req.url === '/enviarMensaje') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString(); // convert Buffer to string
        });

        req.on('end', () => {
            const mensaje = JSON.parse(body).mensaje;
            const carrera = "INGC";

            // Aquí puedes ejecutar tu segundo script o realizar cualquier otra acción con el mensaje
            console.log('Mensaje recibido:', mensaje);

            askQuestionBot(mensaje, carrera).then(respuesta => {
                console.log(respuesta);
                //Envía una respuesta al cliente
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ respuesta: respuesta }));
              }).catch(error => {
                console.error("Ocurrió un error:", error);
                // Envía una respuesta al cliente
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ respuesta: "ha ocurrido un error" }));
            });
        });
    } 
    // Enviar comentarios de feedback a la base de datos
    else if (req.method === 'POST' && req.url === '/enviarFeedback') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString(); // convert Buffer to string
        });
        req.on('end', () => {
            const pregunta = JSON.parse(body).pregunta;
            const respuesta = JSON.parse(body).respuesta;
            const feedback = JSON.parse(body).feedback;
            submitFeedback(218695839, pregunta, respuesta, feedback).then(() => {
                // Enviar una respuesta de éxito al cliente
                res.writeHead(200, { 'Content-Type': 'text/plain' });
                res.end('Feedback enviado correctamente');
            }).catch(error => {
                console.error("Error al procesar el feedback:", error);
                // Enviar una respuesta de error al cliente
                res.writeHead(500, { 'Content-Type': 'text/plain' });
                res.end('Error al procesar el feedback');
            });
        });
    } else {
        let filePath = '.' + req.url;
        if (filePath === './') {
            filePath = './index.html';
        }

        const extname = String(path.extname(filePath)).toLowerCase();
        const contentType = {
            '.html': 'text/html',
            '.css': 'text/css',
            '.js': 'text/javascript',
        }[extname] || 'application/octet-stream';

        fs.readFile(filePath, (err, content) => {
            if (err) {
                if (err.code === 'ENOENT') {
                    res.writeHead(404);
                    res.end('Archivo no encontrado');
                } else {
                    res.writeHead(500);
                    res.end('Error interno del servidor');
                }
            } else {
                res.writeHead(200, { 'Content-Type': contentType });
                res.end(content, 'utf-8');
            }
        });
    }
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}/`);
});
