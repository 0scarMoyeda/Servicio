const { stringSimilarity } = require('string-similarity-js');
const { getTutor } = require('./serviciotutorJS/Tutorias');
const { responderPregunta } = require('./servicioOpenAI/openAI');
const { responderTutor } = require('./servicioOpenAI/openAI');

//Verificamos si el usuario pide a su tutor
function checkIfTutor(question) {
    //console.log(stringSimilarity("¿Quien es mi tutor?", question));
    //Si la similitud es mayor a 0.36 entonces quiere su tutor.
    if(stringSimilarity("¿Quien es mi tutor?", question) > 0.36){
        return "¿Quien es mi tutor?";
    }else{
        return "No se encontraron similitud";
    }
}

//Funcion para decidir si responder a la pregunta tutor o a preguntas generales.
async function askQuestionBot(pregunta, carrera) {
    const checkTutor = checkIfTutor(pregunta);

    //Si quiere su tutor lo obtenemos y llamamos a gpt para generar una respuesta
    //Si no, solo llamamos a gpt para responder dudas generales.
    if (checkTutor === "¿Quien es mi tutor?") {
        //return("Tu tutore es: vaporeon");
        const tutor = await getTutor();
        return responderTutor(pregunta, carrera, tutor);
    } else {
        //return("Asi que no quiere tutor e mu mal muchacho");
        return responderPregunta(pregunta, carrera);
    }
}

module.exports = {
    askQuestionBot
}