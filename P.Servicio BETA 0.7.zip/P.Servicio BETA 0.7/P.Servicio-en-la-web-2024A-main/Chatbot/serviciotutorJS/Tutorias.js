const mysql = require('mysql');
const codigoAlumno = "218695839";

//Conexión con la base de datos tutores
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  pass: '',
  database: 'tutores'
});

connection.connect(err => {
  if(err) {
    console.error(err);
    return
  }
    console.log("conexion establecida");
});

//Función para obtener el tutor de la base de datos
function getTutor(){
  return new Promise((resolve, reject) => {
    connection.query('SELECT * FROM tutores WHERE Codigo = '+codigoAlumno, (error, rows) => {
      if(error){
        reject(error);
        return;
      }
      console.log(rows);
      try{
        const answer = "El tutor asociado al codigo " + rows[0].Codigo + " es " + rows[0].NombreTutor + " puedes contactarlo con el correo " + rows[0].CorreoTutor;
        resolve(answer);
      }catch(err){
        const noEncontrado = "No tengo conocimiento sobre tu tutor, puedes pedir informes sobre el en coordinacion";
        resolve(noEncontrado);
      }
    });
  });
}

module.exports = {
  getTutor
}